<script>
export default {


  data() {
    return {
      params: {
        clase: '2º DAW'
      },
      counter: 0
    }
  },
  methods: {
    saludaConEvento(event) {
      alert(`¡Hola ${this.params.clase}!`)

      if (event) {
        alert("El evento es " + event.type)
      }
    },

    saludaEnLinea(nombre) {
      alert(`¡Hola ${nombre}!`)
    },

    aviso(message, event) {
      if (event) {
        event.preventDefault()
      }
      alert(message)
    }


  }

}
</script>

<template>

  <h2>Options</h2>

  La manera de obtener datos viene de objetos.
  <pre  style="text-align: left;margin-left: 43%  "><code>
  data() {
    return {
      params: {
        nombre: '2º DAW'
      },
      counter: 0
    }
  },
  methods: {
    saludaConEvento(event) {
      alert(`¡Hola ${this.params.nombre}!`)

      if (event) {
        alert("El evento es " + event.type)
      }
    },
  </code></pre>

  <h2>Composition</h2>
  En este enfoque, las funciones son responsables de definir el estado y el comportamiento del componente.

  <pre  style="text-align: left;margin-left: 43% "><code>

    clase = '2º DAW'

    function  saludaConEvento(event) {
      alert(`¡Hola ${this.params.clase}!`)

      if (event) {
        alert("El evento es " + event.type)
      }
    }
  </code></pre>

  <hr style="width: 70%">

  <h3>Manejo de eventos</h3>
  <hr style="width: 50%">

  <div>
    <h4>Llamando un evento sencillo</h4>
    <div>Se usan para llamadas sencillas</div>
    <br> <br>
    <div><strong> Llamada </strong> <br> <br> @click="counter++"</div>
    <br>

    <button @click="counter++">Suma 1</button>
    <br>
    <p>El botón de arriba se pulsado {{ counter }} veces.</p>

  </div>
  <hr style="width: 50%">

  <div>
    <h4>Llamando métodos</h4>
    <div>Options: Se define dentro de "methods"</div>
    <div>Composition: Se crea una funcion igual que en js</div>
    <br>
    <div><strong> Llamada </strong><br> <br> @click="saludaConEvento"</div>
    <br>
    <button @click="saludaConEvento">Saluda</button>
    <br>
  </div>
  <hr style="width: 50%">

  <div>
    <h4>Llamando métodos en línea</h4>
    <div>Permite pasarle parámetros</div>
    <br>
    <div><strong> Llamada </strong><br><br> @click="saludaEnLinea('clase')"</div>
    <br>
    <button @click="saludaEnLinea('clase')">Saluda</button>
  </div>
  <hr style="width: 50%">

  <div>
    <h4>Accediendo al evento en métodos en linea</h4>
    <div>Se puede pasar con un método usando $event o con una función flecha, para tener acceso al evento nativo</div>
    <br>
    <!--    <hr style="width: 40%">-->

    <h4>Con $event</h4>
    <div><strong> Llamada </strong><br> <br> @click="aviso('No puede ser enviado.', $event)"</div>
    <br>
    <button @click="aviso('No puede ser enviado.', $event)">
      Enviar
    </button>
    <br> <br>
    <hr style="width: 10%">


    <h4>Con función flecha</h4>

    <div><strong> Llamada </strong><br><br> @click="(event) => aviso('No puede ser enviado.', event)"</div>
    <br>
    <button @click="(event) => aviso('No puede ser enviado.', event)">
      Enviar
    </button>
  </div>


  <br>


  <hr style="width: 50%">

  <div>
    <h4>Modificadores de eventos en Vue.js</h4>
    <p>Los modificadores de eventos son útiles para personalizar el comportamiento de los eventos en Vue.js.</p>

    <ul>
      <li><code>.stop</code>: Detiene la propagación del evento más allá del elemento actual.</li>
      <li><code>.prevent</code>: Evita el comportamiento predeterminado de un evento.</li>
      <li><code>.self</code>: Limita el evento a escuchar solo en el elemento actual.</li>
      <li><code>.capture</code>: Maneja el evento en el elemento más externo primero y luego se propaga hacia abajo.
      </li>
      <li><code>.once</code>: Escucha el evento solo una vez y luego se elimina automáticamente.</li>
      <li><code>.passive</code>: Optimiza el rendimiento de los eventos táctiles en dispositivos móviles.</li>
    </ul>

    <p>También se pueden usar modificadores para eventos de teclado y ratón:</p>

    <ul>
      <li><code>@keyup.enter</code></li>
      <li><code>@keyup.tab</code></li>
      <li><code>@keyup.delete</code></li>
      <li><code>@keyup.up</code></li>
      <li><code>@click.left</code></li>
      <li><code>@click.right</code></li>
      <li><code>@click.middle</code></li>
    </ul>

    <p>El modificador <code>.exact</code> se utiliza para garantizar que un evento solo se maneje si coincide
      exactamente con la tecla modificadora especificada.</p>
  </div>

  <br>


</template>

<style>

ul {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

/** {*/
/*  text-align: center;*/
/*}*/
</style>
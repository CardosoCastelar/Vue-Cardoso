<template>
  <img alt="Vue logo" src="./assets/logo.png">
  <h1> Proyecto VUE Javier Cardoso</h1>
  <h2> Manejo de eventos</h2>
  <hr>
  <EventosCardoso/>
  <hr>
</template>

<script>


import EventosCardoso from "@/components/EventosCardoso.vue";


export default {
  name: 'App',
  props: {
    msg: String
  },
  components: {
    EventosCardoso


  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
